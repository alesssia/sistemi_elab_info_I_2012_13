#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

main()
{
	printf("Sono il processo con PID=%d\n", getpid());
	
	char *newargv[] = {"/bin/ls", "-a", NULL };
	char *newenviron[] = { NULL };
	execve("/bin/ls", newargv, newenviron);
	
	printf("Impossibile eseguire il comando richiesto\n");
	exit(1);
}
