#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv)
{

	int status;

	int pid = fork();
	if (pid < 0) 
	{
		exit(1);
	}
	
	if (pid != 0)
	{
		printf("[Padre] PID=%d\n", getpid());
		wait(&status);
		printf("[Padre] Il figlio PID=%d ha finito e anche io. Ciao!\n", pid);
	}
	else
	{
		printf("[Figlio] PID=%d, PID padre=%d\n", getpid(), getppid());
		sleep(3);
		printf("[Figlio] Ho dormito adesso termino\n");
		exit(0);
	}
	
	exit(0);
}
