#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv)
{
	int pid;
	unsigned int i;
	printf("[Padre] Sono il padre sto per generare in miei figli\n");

	for(i=0; i<5; i++)
	{
		pid = fork();
		if (pid < 0) 
		{
			exit(1);
		}
		if (pid == 0)
		{
			printf("[Figlio] Ciao, sono PID=%d\n", getpid());
			//uno dei modi per creare numeri casuali è la rand(), che necessita il
			//set di un seed (vedi srand(unisigned int seed)) per creare numeri (pseudo)
			//causuali. Se il seed è il medesimo i numeri estratti dalla rand()
			//saranno i medesimi. Serve perciò un seed univoco per ciascun processo
			//Esempio di valore univoco è il PID.
			srand(getpid());
			unsigned int s = rand()%9;
			sleep(s);
			printf("[Figlio] Sono PID=%d. Ho dormito %d secondi e termino\n", getpid(), s);
			exit(0);
		}
	}

	if (pid != 0)
	{
		while ((wait(NULL)) != -1);
		printf("[Padre] Tutti i miei figli si sono riposati: termino\n");
	}
	
	exit(0);
}
