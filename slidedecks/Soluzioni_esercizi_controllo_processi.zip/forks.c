#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main(int argc, char** argv)
{
	unsigned int i;
	unsigned int n;
	for (i=0; i<3; i++)
	{
		n = fork();
		if (n == 0)
		{
			printf("Sono il figlio\n");
			//exit(0);
		}
		{
			printf("Sono il padre\n");
		}
	}
}
