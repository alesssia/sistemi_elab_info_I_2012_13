/*
 * client.c
 */

#include "header.h"

int main(int argc, char **argv)
{

	/********************
	 * check parameters
	 ********************/

	if(argc != 2)
	{
		printf("usage: ./client hostname\n");
		exit(1);
	}


	//variable declaration
	int status;
	int sock;
	char buffer[MAXDATA];
	//...

	/********************
	 * set up structure
	 ********************/

	struct addrinfo hints;
	memset(&hints, 0, sizeof hints);	//an empty structure is needed
	//family and socket types must be set
	//...

	struct addrinfo *res;				//resulting structure
	//fulfill the addrinfo structure, and check for errors
	//...
	

	/********************
	 * socket creation and connect
	 ********************/

	struct addrinfo *r;

	//Server should check for a valid entry in the res linked list (who knows if the
	//first one is good?)
	for(r = res; r != NULL; r = r->ai_next)
	{
		//obtain a socket descriptor. If an error occurs, continue to the next result
		//...


		//client needs to connect the port Server is on, and check for errors
		//...

		break; 							//this entry worked
	}


	if (r == NULL) //no valid entry found
	{
		printf("    [CLIENT] Client failed to connect\n");
		exit(1);
	}


	/********************
	 * print socket address
	 ********************/

	// Get socket address 
	void *addr = get_addr_sock((struct sockaddr *)r->ai_addr);

	//Convert the address in the dotted-decimal notation, and print it
	//...
	
	freeaddrinfo(res); 					//this struct did its job

	/********************
	 * receive message 
	 ********************/
	 
	//message received, and printed; error check
	//...

	/********************
	 * close socket
	 ********************/	

	//...

	exit(0);
}
