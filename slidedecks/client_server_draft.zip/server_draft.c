/*
 * server.c
 */

#include "header.h"



void sigchld_handler(int s)
{
	//Sever waits for all its children
	while ((wait(NULL)) != -1);
}


int main(int argc, char **argv)
{
	//variable declarations
	int status;
	char ip[INET6_ADDRSTRLEN];


	/********************
	 * set up structure
	 ********************/

	//node can be set either to: i) service you would like to connect to (e.g., "www.example/net");
	//							ii) an IP address;
	//							iii) NULL, in order to connect on local host.
	char *node = NULL;
	char *service = PORT;	

	struct addrinfo hints;
	memset(&hints, 0, sizeof hints);	//an empty structure is needed
	//family, flag and socket types must be set
	//...	 

	struct addrinfo *res;				//resulting structure
	//fulfill the addrinfo structure, and check for errors
	//...

	//let Server print IPs belonging to the resulting linked list
	struct addrinfo *r;
	void *addr;
	
	for(r = res; r != NULL; r = r->ai_next)
	{
		//address IPv4 are different than those IPv6
		addr = get_addr_sock((struct sockaddr *)r->ai_addr);
		
		//Convert the address in the dotted-decimal notation, and print it
		//...
	}

	/********************
	 * make a socket, bind and listen
	 ********************/

	int sock_ls;	//Server listens on this socket 

	//Server should check for a valid entry in the res linked list (who knows if the
	//first one is good?)
	for(r = res; r != NULL; r = r->ai_next)
	{
		//obtain a socket descriptor. If an error occurs, continue to the next result
		//...


		int yes = 1;
		status = setsockopt(sock_ls, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
		if (status == -1)
		{
			perror("Server: setsocketopt");
			exit(1);					//Server fails
		}

		//Server needs to bind the port it is on, error checking
		//...

		break; 							//this entry worked
	}


	if (r == NULL)
	{
		printf("    [SERVER] Server did not get any socket\n");
		exit(1);
	}

	freeaddrinfo(res); 					//this struct did its job

	//Server listens to the given socket, end error checking
	//...


	/********************
	 * handling signal
	 ********************/

	//avoids zombies
	struct sigaction sa;
	sa.sa_handler = sigchld_handler;	
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	status = sigaction(SIGCHLD, &sa, NULL);
	if (status == -1)
	{
		perror("Server: sigaction, SIGCHLD");
		exit(1);
	}


	/********************
	 * serve clients
	 ********************/


	int sock_nc;	//New connections' socket

	//Clients' data structure
	socklen_t addr_size;
	struct sockaddr_storage client_addr;

	printf("\n    [SERVER] Ready\n    [SERVER] Waiting for connections...\n");

	//Server will accept all the connections it receives
	while(1)
	{
		//accept connection, and check errors
		//...

		//Print the accepted connection
		addr = get_addr_sock((struct sockaddr *)&client_addr);
		//Convert the address in the dotted-decimal notation, and print it
		//...

		int pid = fork();
		if (pid == 0)		
		{
			close(sock_ls); 			//child does not listen
			
			//send message and check errors
			//...
			
			//close socket
			//...
			exit(0);
		}
		
		close(sock_nc);					
	}

	return 0;
}

