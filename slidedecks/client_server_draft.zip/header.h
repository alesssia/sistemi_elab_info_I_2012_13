/*
 * header.h
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/wait.h>
#include <signal.h>


#define PORT "4242" 				//(It must be higher that 1024)
#define SOCKET_FAMILY AF_UNSPEC 	//nevermind if will be IPv3 or IPv6
#define SOCKET_TYPE SOCK_STREAM  	//TCP stream sockets will be used
#define BACKLOG 8					//max clients waiting
#define MAXDATA 128					//max number of bytes received at a time




void *get_addr_sock(struct sockaddr *sa_addr)
{
	//taking into account IP versione
	void *addr;
	if (sa_addr->sa_family == AF_INET) 	//IPv4
	{
		struct sockaddr_in *ipv4 = (struct sockaddr_in *)sa_addr;
		addr = &(ipv4->sin_addr);
	}
	else 								//IPv6	
	{
		struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)sa_addr;
		addr = &(ipv6->sin6_addr);
	}

	return(addr);
}
